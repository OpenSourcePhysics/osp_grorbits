(function(){var P$=Clazz.newPackage("java.awt.event"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "MouseMotionAdapter", null, null, 'java.awt.event.MouseMotionListener');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'mouseDragged$java_awt_event_MouseEvent', function (e) {
});

Clazz.newMeth(C$, 'mouseMoved$java_awt_event_MouseEvent', function (e) {
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.7-v3');//Created 2020-01-18 17:07:47 Java2ScriptVisitor version 3.2.7-v3 net.sf.j2s.core.jar version 3.2.7-v3
